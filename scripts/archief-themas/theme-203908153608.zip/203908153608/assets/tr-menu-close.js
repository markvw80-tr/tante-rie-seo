/* Tante Rie - close submenu on scroll
   On real scroll movement: add body.tr-menu-force-closed (CSS hides submenu).
   On next mouse movement: remove class, allow submenu open again.

   Two guards prevent a menu that just opened from being force-closed by a
   scroll event the menu itself (or a sticky filter/USP bar below a
   collection-page header) triggers as a side effect of opening:
   1. a distance threshold, ignoring near-zero scroll jitter;
   2. skip entirely while a top-level menu link is expanded/hovered, since
      any scroll firing at that moment is virtually never real scroll-away
      intent from the visitor. */
(function () {
  let suppressed = false;
  let lastScrollY = window.scrollY;
  const THRESHOLD = 8;

  function menuIsActive() {
    return !!document.querySelector(
      '.menu-list__link[aria-expanded="true"], .menu-list__submenu:hover, .menu-list__list-item:hover'
    );
  }

  function suppress() {
    if (!suppressed) {
      document.body.classList.add('tr-menu-force-closed');
      suppressed = true;
    }
  }

  function release() {
    if (suppressed) {
      document.body.classList.remove('tr-menu-force-closed');
      suppressed = false;
    }
  }

  function onScroll() {
    const currentScrollY = window.scrollY;
    const delta = Math.abs(currentScrollY - lastScrollY);
    lastScrollY = currentScrollY;
    if (delta <= THRESHOLD) return;
    if (menuIsActive()) return;
    suppress();
  }

  window.addEventListener('scroll', onScroll, { passive: true });
  document.addEventListener('mousemove', release, { passive: true });
  document.addEventListener('touchstart', release, { passive: true });
})();
