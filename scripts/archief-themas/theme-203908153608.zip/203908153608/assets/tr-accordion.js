/* Tante Rie - shared accordion (single-open within each group)
   Usage:
     <div data-tr-accordion>
       <div>
         <button data-tr-accordion-trigger aria-expanded="false">Title</button>
         <div data-tr-accordion-body>...</div>
       </div>
       ...
     </div>
   CSS: target [data-tr-accordion-body].open for visual open state.
   The trigger gets aria-expanded toggled and an .open class for chevron rotation. */
(function () {
  document.addEventListener('click', function (e) {
    const trigger = e.target.closest('[data-tr-accordion-trigger]');
    if (!trigger) return;
    const group = trigger.closest('[data-tr-accordion]');
    if (!group) return;
    const body = trigger.nextElementSibling;
    const wasOpen = body && body.classList.contains('open');

    group.querySelectorAll('[data-tr-accordion-trigger]').forEach(function (t) {
      t.classList.remove('open');
      t.setAttribute('aria-expanded', 'false');
    });
    group.querySelectorAll('[data-tr-accordion-body]').forEach(function (b) {
      b.classList.remove('open');
    });

    if (!wasOpen && body) {
      body.classList.add('open');
      trigger.classList.add('open');
      trigger.setAttribute('aria-expanded', 'true');
    }
  });
})();
