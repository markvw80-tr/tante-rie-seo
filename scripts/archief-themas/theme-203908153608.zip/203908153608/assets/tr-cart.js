/* Tante Rie - shared add-to-cart handler
   Compatible with Horizon's cart drawer / cart icon.

   Usage:
     <button data-tr-atc data-variant-id="123"
             data-qty-from="#tr-qty"
             data-success-text="✓ Toegevoegd">
       Aan winkelwagen toevoegen
     </button>

   Attributes:
   - data-qty-from (optional): selector for an element whose textContent holds the qty. Defaults to 1.
   - data-success-text (optional): button label shown during the 2s success state. Defaults to "Toegevoegd".

   On success the handler:
   1. POST /cart/add.js
   2. GET /cart.js for the updated cart resource
   3. Dispatches a "cart:update" CustomEvent matching Horizon's CartAddEvent contract
      (event.detail.resource = cart, with item_count) so the cart icon updates and
      the drawer auto-opens when settings.auto_open_cart_drawer is enabled.
   Adds .tr-atc-added class during success; sections may style it (e.g. green background). */
(function () {
  const SUCCESS_MS = 2000;

  function pickQty(btn) {
    const sel = btn.dataset.qtyFrom;
    if (!sel) return 1;
    const el = document.querySelector(sel);
    if (!el) return 1;
    const n = parseInt(el.textContent, 10);
    return n > 0 ? n : 1;
  }

  function reset(btn) {
    btn.textContent = btn.dataset.trOriginalText || btn.textContent;
    btn.classList.remove('tr-atc-added');
    btn.disabled = false;
  }

  function dispatchCartUpdate(cart, variantId) {
    document.dispatchEvent(new CustomEvent('cart:update', {
      bubbles: true,
      detail: {
        resource: cart,
        sourceId: 'tr-cart',
        data: {
          source: 'tr-cart',
          itemCount: cart && cart.item_count,
          variantId: variantId
        }
      }
    }));
  }

  function handle(btn) {
    const variantId = btn.dataset.variantId;
    if (!variantId || btn.disabled) return;
    if (!btn.dataset.trOriginalText) btn.dataset.trOriginalText = btn.textContent;
    const qty = pickQty(btn);
    btn.textContent = btn.dataset.successText || 'Toegevoegd';
    btn.classList.add('tr-atc-added');
    btn.disabled = true;

    fetch('/cart/add.js', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'Accept': 'application/json' },
      body: JSON.stringify({ id: variantId, quantity: qty })
    })
      .then(function (r) {
        if (!r.ok) throw new Error('cart add failed: ' + r.status);
        return fetch('/cart.js', { headers: { 'Accept': 'application/json' } });
      })
      .then(function (r) { return r.json(); })
      .then(function (cart) {
        dispatchCartUpdate(cart, variantId);
        setTimeout(function () { reset(btn); }, SUCCESS_MS);
      })
      .catch(function (err) {
        console.error('[tr-cart]', err);
        reset(btn);
      });
  }

  document.addEventListener('click', function (e) {
    const btn = e.target.closest('[data-tr-atc]');
    if (btn) handle(btn);
  });
})();
