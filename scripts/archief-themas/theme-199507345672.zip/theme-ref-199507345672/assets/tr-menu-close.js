/* Tante Rie - close submenu on scroll
   On real scroll movement: add body.tr-menu-force-closed (CSS hides submenu).
   On next mouse movement: remove class, allow submenu open again.

   Guards preventing a menu that just opened from being force-closed by a
   scroll event the menu itself (or a sticky filter/USP bar below a
   collection-page header) triggers as a side effect of opening:
   1. a distance threshold, ignoring near-zero scroll jitter;
   2. skip entirely while a top-level menu link is expanded/hovered, or while
      a submenu is marked active by header-menu.js (data-active), since a
      scroll firing at that moment is virtually never real scroll-away
      intent from the visitor;
   3. a short ignore-window right after entering a menu item, to swallow
      scroll-anchoring corrections the browser fires when the header grows
      to make room for the opening submenu (the most common false trigger). */
(function () {
  let suppressed = false;
  let lastScrollY = window.scrollY;
  let ignoreUntil = 0;
  const THRESHOLD = 8;
  const IGNORE_WINDOW_MS = 350;

  function menuIsActive() {
    return !!document.querySelector(
      '.menu-list__link[aria-expanded="true"], .menu-list__submenu[data-active], .menu-list__submenu:hover, .menu-list__list-item:hover'
    );
  }

  function suppress() {
    if (!suppressed) {
      document.body.classList.add('tr-menu-force-closed');
      suppressed = true;
    }
  }

  function release() {
    if (suppressed) {
      document.body.classList.remove('tr-menu-force-closed');
      suppressed = false;
    }
  }

  function extendIgnoreWindow() {
    ignoreUntil = Date.now() + IGNORE_WINDOW_MS;
  }

  function onScroll() {
    const currentScrollY = window.scrollY;
    const delta = Math.abs(currentScrollY - lastScrollY);
    lastScrollY = currentScrollY;
    if (delta <= THRESHOLD) return;
    if (Date.now() < ignoreUntil) return;
    if (menuIsActive()) return;
    suppress();
  }

  function onPointerEnterCapture(event) {
    const target = event.target;
    if (target && target.closest && target.closest('.menu-list__list-item')) {
      extendIgnoreWindow();
    }
  }

  window.addEventListener('scroll', onScroll, { passive: true });
  document.addEventListener('mousemove', release, { passive: true });
  document.addEventListener('touchstart', release, { passive: true });
  document.addEventListener('pointerenter', onPointerEnterCapture, { passive: true, capture: true });
})();